"""
Minimal PWA injector for Streamlit apps.
Call inject_pwa() once near the top of your main script.
"""

import streamlit.components.v1 as components


def inject_pwa():
    """Inject manifest link + service-worker registration into the page."""
    components.html(
        """
        <link rel="manifest" href="/app/static/manifest.json">
        <meta name="theme-color" content="#0E1117">
        <meta name="mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
        <script>
          if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
              navigator.serviceWorker.register('/app/static/sw.js')
                .then(reg => console.log('Appraze SW registered:', reg.scope))
                .catch(err => console.log('Appraze SW registration failed:', err));
            });
          }
        </script>
        """,
        height=0,
    )
