// Minimal service worker for Appraze PWA installability.
// No aggressive caching — the app is fully server-backed.

const CACHE_NAME = 'appraze-v1';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
  // Pass-through only. Do not cache dynamic Streamlit responses.
  event.respondWith(fetch(event.request));
});
