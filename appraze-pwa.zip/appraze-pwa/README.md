# Appraze PWA Bundle

Drop these files into your Appraze Streamlit repo to make the live app installable (home-screen icon + standalone chrome). Offline appraisal is **not** supported — the app still requires the Python backend.

## Files

```
.streamlit/config.toml     # enables static file serving
static/
  manifest.json            # web app manifest
  sw.js                    # minimal service worker
  icon-192.png             # placeholder icon (replace with real art)
  icon-512.png             # placeholder icon (replace with real art)
pwa_inject.py              # 3-line helper
```

## Integration (3 lines)

In your main Streamlit script (near the top):

```python
from pwa_inject import inject_pwa
inject_pwa()
```

## Deploy steps

1. Commit & push these files to the Appraze-ai repo (or upload via GitHub UI).
2. Redeploy the Streamlit app.
3. Open the live URL in Chrome → you should see the “Install app” prompt.
4. Confirm in DevTools → Application → Manifest + Service Workers.
5. Paste the live URL into https://www.pwabuilder.com → Generate → download the Android package.

## Customization

- Replace `static/icon-*.png` with your real branding.
- Edit `manifest.json` name / colors / description as needed.
- Paths assume Streamlit’s `/app/static/` serving. If you place files at repo root instead, update the `src` and `href` values accordingly.
